SERVER, CLIENT and UI scripts for **R5pc_r5launch_N1094_CL456479_2019_10_30_05_20_PM**.
This has to be cloned in the **platform** folder of the game.
The resulting path to **scripts.rson** should be `[game directory]\platform\scripts\vscripts\scripts.rson`
